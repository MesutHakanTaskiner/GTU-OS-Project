# CSE513 Assignment 1 — CPU Scheduling Simulator

## Instructor Requirements and Acceptance Checklist

**Source:** `CSE513-Assignment-1.pdf` (4 pages). This document reorganizes the instructor's requirements into a checklist for implementation and submission. The source PDF remains authoritative if there is any ambiguity.

**Assignment objective:** Develop a **browser-based simulator** demonstrating how CPU scheduling algorithms select processes and how their decisions affect performance. Both the implementation and the explanation of scheduling decisions must be correct.

## 1. Required scheduling algorithms

- [ ] First-Come, First-Served (**FCFS**).
- [ ] Shortest Job First (**SJF**, **non-preemptive**).
- [ ] Shortest Remaining Time First (**SRTF**, **preemptive**).
- [ ] Round Robin (**RR**, configurable time quantum).

### Simulation model and validation

- [ ] Model **one CPU** only.
- [ ] Give each process **one CPU burst**, with **no I/O**.
- [ ] Set context-switching overhead to **zero**.
- [ ] Require arrival times to be **nonnegative integers**.
- [ ] Require CPU bursts and RR quantum to be **positive integers**.
- [ ] Require **unique process IDs**.
- [ ] Never leave the CPU idle if at least one eligible process is ready.
- [ ] Reject invalid inputs with a **clear explanation**.

### Exact scheduling semantics (critical)

- **FCFS:** Select the ready process with the earliest arrival time.
- **SJF:** When the CPU becomes free, select the ready process with the shortest original CPU burst; do not preempt it.
- **SRTF:** Select the ready process with the shortest remaining CPU time. Preempt the currently running process **only if another process has a strictly shorter remaining time**. On equality, keep the currently running process.
- **Tie-breaking:** When processes are otherwise tied for selection, prefer the earlier arrival time; if still tied, prefer the earlier **position in the input list**.
- **RR:** Maintain a **FIFO** ready queue. New arrivals join the tail. At a quantum boundary, enqueue processes arriving **at that exact time** before re-enqueuing the unfinished running process. Never re-enqueue a completed process.
- **Idle:** When no process is ready, represent the idle interval up to the next arrival.
- **Intervals:** Use consistent half-open interval logic: running from time 2 to 5 accounts for **3 units** of CPU time.

## 2. Website requirements

The browser-based website must allow a user to:

- [ ] Add, edit, and remove processes.
- [ ] Set each process's **ID**, **arrival time**, and **CPU burst**.
- [ ] Choose one of the four scheduling algorithms.
- [ ] Configure the RR time quantum.
- [ ] Run a simulation and inspect its results.
- [ ] Load the instructor-supplied example workload.
- [ ] See a **labeled Gantt chart**, **including CPU idle intervals**.
- [ ] Identify RR **quantum boundaries even when the same process gets consecutive time slices**.
- [ ] See a results table containing, **for every process**:
  - arrival time;
  - CPU burst;
  - first start time;
  - completion time;
  - turnaround time;
  - waiting time;
  - response time.
- [ ] See **average turnaround**, **average waiting**, and **average response** time.

### Required metric definitions

```text
Turnaround time = Completion time - Arrival time
Waiting time    = Turnaround time - CPU burst
Response time   = First start time - Arrival time
```

A simple, readable interface is sufficient. A separate backend, database, login system, and paid hosting are **not required**.

## 3. Instructor-provided workloads

Run **both workloads under all four algorithms** (8 algorithm–workload combinations). For **Round Robin, use quantum = 2** for these required examples.

### Workload A

| Input position | Process | Arrival time | CPU burst |
|---:|---|---:|---:|
| 1 | P1 | 0 | 8 |
| 2 | P2 | 1 | 4 |
| 3 | P3 | 2 | 2 |
| 4 | P4 | 4 | 1 |

### Workload B

| Input position | Process | Arrival time | CPU burst |
|---:|---|---:|---:|
| 1 | P1 | 2 | 3 |
| 2 | P2 | 2 | 1 |
| 3 | P3 | 8 | 2 |
| 4 | P4 | 9 | 1 |

### Required hand calculations and comparison

- [ ] **Before using the simulator to obtain the answers**, calculate the schedules/timelines and metrics **by hand**, independently.
- [ ] Include the **hand-calculated timelines and metrics** for all 8 combinations in the PDF report.
- [ ] Include the corresponding **simulator outputs**.
- [ ] Compare each simulator output against the hand calculations.
- [ ] Explain and resolve every discrepancy, if any.

**Important interpretation:** The assignment says *calculate by hand*; it does **not explicitly require handwritten pages or handwriting**. Independently derived, legible calculations in the PDF are appropriate unless the instructor gives a separate clarification. Screenshots alone do not replace calculations.

## 4. Three additional student-designed test workloads

Create **at least three** additional workloads, including:

- [ ] A workload with **CPU idle time**.
- [ ] A workload with **simultaneous arrivals and a scheduling tie**.
- [ ] A workload where **SRTF preempts a running process**.

For **each** test:

- [ ] State the behavior being tested.
- [ ] Provide the **expected result** (not only a screenshot).

Also verify the following invariants:

- [ ] Every process receives **exactly its specified CPU burst**.
- [ ] No process runs **before its arrival**.
- [ ] Processes **never overlap** on the single CPU.
- [ ] Waiting and response times are **nonnegative**.
- [ ] The CPU is **never idle while a process is ready**.

## 5. Required written analysis (all six questions)

Answer these questions in a **short report**:

1. For Workload A, which algorithm yields the **lowest average waiting time**? Which yields the **lowest average response time**? Explain the scheduling decisions behind those results.
2. How do RR results change for **quantum = 1, 2, and 4**? Explain why a smaller quantum does **not necessarily improve every metric**.
3. Under what conditions do **SJF and SRTF** produce the **same schedule**? Give an example.
4. Why must a **real operating system estimate future CPU bursts**, whereas the simulator uses exact values?
5. Can **starvation** occur under SJF or SRTF if new short jobs continue arriving? Contrast this with the **finite workloads** used in the assignment.
6. Describe **one real implementation mistake encountered** and explain how a test exposed it. **Do not fabricate a bug; record an actual debugging example.**

The simulator models scheduling policies; it **does not reproduce Ubuntu's actual scheduler**.

## 6. AI assistance disclosure

AI assistance is **permitted** for implementation, debugging, and explanation, but the student is responsible for the correctness of all submitted materials.

Include a brief account of:

- [ ] Which AI tools were used and **for what purposes**.
- [ ] How AI-generated code or explanations were **checked**.
- [ ] One AI suggestion that was **corrected or rejected**, **if applicable**.

The student must be able to explain the implementation and trace scheduling decisions for an **unfamiliar workload**.

## 7. Exact submission requirements

Submit via **Microsoft Teams**:

- [ ] **PDF report** (not Word and not merely screenshots).
- [ ] Put the **working public website URL immediately below the assignment heading on the PDF's first page**.
- [ ] Make that link **clickable** and verify it opens **without asking for access permission**.
- [ ] Submit the **complete source code ZIP**, **or** include a publicly accessible repository link in the PDF.
- [ ] Include a **README with the source** documenting local launch instructions, dependencies, and any limitations.
- [ ] Include **at least two worked examples for each algorithm** (FCFS, SJF, SRTF, RR): use **Workloads A and B** (8 total).
- [ ] For every worked example, provide **input data**, **hand-calculated timeline and metrics**, **simulator output**, and a **discrepancy comparison**.
- [ ] Include the **three additional tests** in the PDF.
- [ ] Include answers to all **six analysis questions** in the PDF.
- [ ] Include the **AI-use statement** in the PDF.
- [ ] Include a **locally runnable version** with the source submission.
- [ ] **Do not publish student numbers or other private information** on the website.
- [ ] Be prepared for a demonstration and for questions about the effects of changing an **arrival time**, **burst**, or **quantum**.

**Deadline:** To be announced (according to the assignment PDF).

## 8. Grading rubric

| Criterion | Weight |
|---|---:|
| Algorithm correctness and scheduling-rule compliance | **50%** |
| Tests, hand calculations and verification | **20%** |
| Explanation and comparative analysis | **20%** |
| Interface usability and clear results | **10%** |

The instructor explicitly prioritizes **correct reasoning and reproducible results** over visual polish.

## 9. Project-specific implementation choice (not an instructor mandate)

The following is the **chosen engineering approach**, not a requirement written by the instructor:

- Use **Python** for the scheduling engine.
- Build the browser-based UI with **Streamlit**, with **Plotly** for Gantt charts.
- Keep the scheduling engine separate from UI code so it can be independently tested.
- Run automated tests (e.g., with **pytest**) and compare against independently derived expected outcomes.
- Publish the working app to **Streamlit Community Cloud**, connected to a GitHub repository. Ensure public access and verify the deployed URL in an incognito/private browsing session.
- Keep a local launch path (e.g., `streamlit run app.py`) and document it in README.
- If GitHub/Streamlit account authorization prevents automatic deployment, report that blocker clearly and provide the exact remaining deployment steps. **Never claim the site is live before verifying it.**
- Generate the PDF report only after the public URL is known; if URL publication is blocked, leave an explicit placeholder and mark the deliverable as incomplete rather than inventing a link.

## 10. Final acceptance gate

**Do not mark the assignment complete unless all instructor requirements above have been met and checked.** In particular:

1. All 4 schedulers follow the exact tie-breaking and boundary semantics.
2. All 8 required worked examples have independent hand calculations and matching simulator outputs.
3. All 3 student-designed tests and all 5 correctness invariants are verified.
4. All 6 analysis questions and the AI disclosure are present.
5. A live, permission-free site URL is verified and placed as a clickable link directly under the report title on page 1.
6. The PDF, source/accessible repo, and locally runnable README are ready for Teams submission.
