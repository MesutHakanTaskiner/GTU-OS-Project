# CSE513 Assignment 1 - Independent Requirements Audit

Audit date: 25 October 2026

The checklist was reviewed without assuming that an item was complete merely because it was mentioned in existing documentation. Evidence was taken from the implementation, tests, generated report, and deployment state.

## Satisfied

- FCFS, non-preemptive SJF, preemptive SRTF, and configurable Round Robin are implemented in separate pure scheduling functions.
- Strict SRTF equality behavior, input-order tie-breaking, RR boundary arrivals, explicit idle time, and half-open intervals are covered by exact regression tests.
- Validation rejects blank/duplicate IDs, invalid integer values, invalid quantum, malformed rows, and oversized workloads with explanatory messages.
- The Streamlit interface supports add/edit/remove, both instructor workloads, algorithm selection, RR quantum, Gantt chart, idle display, RR slice boundaries, the full metrics table, and all three averages.
- Workloads A and B are tested under all four policies with RR q=2.
- The report contains all eight hand-derived timelines, per-process metrics, averages, explicit simulator outputs, and discrepancy statements.
- Three required original workloads are included: idle time, simultaneous tie, and SRTF preemption.
- All five required invariants are automated.
- All six analysis questions are answered.
- The AI-use statement is present and includes tools, verification, and a corrected suggestion.
- README, source ZIP, local run instructions, dependency files, report source, and PDF report exist.
- The latest automated run completed with 61 passing tests.

## Still required before submission

1. Open `https://gtu-os-project.streamlit.app/` in a private/incognito browser and confirm that the full app appears without an access request. An unauthenticated HTTP 200 response has already been verified.
2. Run Workload A/FCFS and Workload B/RR q=2 on the public deployment.
3. Confirm that the Plotly chart is interactive and RR boundaries are visible.
4. Optionally produce literal handwritten calculation pages if the instructor separately asks for handwriting. The written assignment requires independent hand calculation, but does not explicitly require handwritten images.

The public URL is now included as a clickable link in the report. The remaining items are final interactive browser checks before submission.

