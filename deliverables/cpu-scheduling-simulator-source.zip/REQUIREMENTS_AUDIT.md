# CSE513 Assignment 1 - Independent Requirements Audit

Audit date: 25 October 2026

The checklist was reviewed without assuming that an item was complete merely because it was mentioned in existing documentation. Evidence was taken from the implementation, tests, generated report, and deployment state.

## Satisfied

- FCFS, non-preemptive SJF, preemptive SRTF, and configurable Round Robin are implemented in separate pure scheduling functions.
- Strict SRTF equality behavior, input-order tie-breaking, RR boundary arrivals, explicit idle time, and half-open intervals are covered by exact regression tests.
- Validation rejects blank/duplicate IDs, invalid integer values, invalid quantum, malformed rows, and oversized workloads with explanatory messages.
- The Streamlit interface supports add/edit/remove, both instructor workloads, algorithm selection, RR quantum, Gantt chart, idle display, RR slice boundaries, the full metrics table, and all three averages.
- Workloads A and B are tested under all four policies with RR q=2.
- The report contains all eight hand-derived timelines, per-process metrics, averages, explicit simulator outputs, and discrepancy statements.
- Three required original workloads are included: idle time, simultaneous tie, and SRTF preemption.
- All five required invariants are automated.
- All six analysis questions are answered.
- The AI-use statement is present and includes tools, verification, and a corrected suggestion.
- README, source ZIP, local run instructions, dependency files, report source, and PDF report exist.
- The latest automated run completed with 61 passing tests.

## Still required before submission

1. Deploy the app to Streamlit Community Cloud.
2. Confirm that the assigned `.streamlit.app` URL opens in a private/incognito browser without authentication.
3. Run at least Workload A/FCFS and Workload B/RR q=2 on the public deployment.
4. Replace the pending notice immediately below the report title with the real clickable public URL.
5. Rebuild and visually verify the final PDF after inserting the URL.
6. Optionally produce literal handwritten calculation pages if the instructor separately asks for handwriting. The written assignment requires independent hand calculation, but does not explicitly require handwritten images.

Until items 1-5 are complete, the deliverable is a tested deployment-ready draft, not a final submission package.

