# CSE513 Assignment 1 — CPU Scheduling Simulator

## Agent mission

Implement, test, document, and prepare deployment of a complete, publicly accessible, browser-based **CPU Scheduling Simulator** for a graduate Operating Systems course. Use **Python** for scheduling logic and **Streamlit** for the website; use **Plotly** for a legible interactive Gantt chart. The application must work locally and be deployable to **Streamlit Community Cloud** with an unrestricted public URL. Deliver the full source code, reproducible tests, README, a polished English PDF report, and a source ZIP. Do not stop after scaffolding or producing pseudocode.

The authoritative assignment specification is `CSE513-Assignment-1.pdf` (four pages). Read it first if it is present in the repository. If any instruction here conflicts with the professor's specification, follow the PDF and document the discrepancy. Do not claim deployment, tests, calculations, or URL validation that did not actually occur.

All code, code comments, documentation, chart labels, the user interface, tests, and the academic report must be in **English**.

## Priority and acceptance criteria

The assessment weights are: scheduling correctness and rule compliance **50%**, tests/hand calculations/verification **20%**, explanation/comparative analysis **20%**, and interface usability **10%**. Optimize for correctness, reproducibility, and explainability before visual polish.

A finished solution must:

1. Provide usable online and locally runnable Streamlit interfaces.
2. Implement FCFS, non-preemptive SJF, preemptive SRTF, and Round Robin exactly as specified.
3. Validate inputs and show helpful, specific errors.
4. Display a labeled Gantt chart (including idle intervals and distinct RR quantum boundaries), per-process metrics, and averages.
5. Work through **both required workloads under all four algorithms**, with RR quantum 2, including independent hand-derived timelines and metric calculations in the PDF report.
6. Include at least **three additional targeted test workloads**, their anticipated outcomes, automated checks, and explanation of what each tests.
7. Answer all six required analysis questions in the report and provide a candid AI-use disclosure.
8. Provide README and deploy instructions, test instructions, a ZIP of source files, and the report PDF. If an authenticated GitHub/Streamlit integration is available, deploy and verify the actual public URL; otherwise complete all preparatory work and state the precise steps/permissions needed for the owner to finish deployment. Never fabricate a URL.

## Required scheduling semantics (critical)

- Exactly **one CPU**. Each process has **one CPU burst** and **no I/O**.
- Context switches consume **zero time**.
- Arrival times are nonnegative **integers**; bursts and RR quantum are strictly positive **integers**; IDs are nonempty and unique.
- The CPU **must not idle** while any eligible/ready process exists.
- Use half-open timeline intervals `[start, end)`. Running from time 2 to 5 consumes exactly 3 units of CPU. Times remain integral.
- Preserve **input list order** as an explicit immutable `input_index`, even when sorting or editing data.
- Tie-breaking when selecting among otherwise tied processes: earlier arrival time, then earlier original input index.
- **FCFS**: select the earliest-arriving ready process; execute non-preemptively to completion.
- **SJF**: when the CPU becomes free, choose the ready process with the smallest *original* CPU burst; execute non-preemptively to completion. Do not incorrectly choose a future, not-yet-arrived short job.
- **SRTF**: select the process with the smallest *remaining* burst. Preempt the currently running process **only if another ready process has strictly shorter remaining time**. When remaining times tie, keep the current process, even if another job has earlier arrival/input index. Apply tie-breaking when choosing a new process, not to defeat the equal-remaining keep-running rule.
- **RR**: FIFO ready queue. New arrivals append to tail. At the boundary where a quantum ends, process **arrivals at that exact timestamp before re-enqueuing the unfinished running process**. A completed process never rejoins the queue. Handle multiple arrivals in arrival time then input order. Handle arrivals occurring inside an active quantum correctly. Keep each RR time slice as a separate chart segment **even when the same process gets consecutive slices**.
- If the ready queue is empty, emit an `IDLE` segment until the next arrival. Include initial idle time (e.g. Workload B begins at t=2) and any intermediate idle gaps.
- Merge adjacent identical execution segments where appropriate for FCFS/SJF/SRTF visualization, but **never merge away RR quantum boundaries**. Keep underlying event/slice fidelity and use it consistently for validation.

### Input validation details

Reject: duplicate IDs; missing/blank IDs; negative arrival; zero/negative burst or quantum; non-integers including decimal floats, booleans, malformed strings, and NaN; malformed rows. Do not silently clamp or coerce fractional values. Treat RR quantum validation as mandatory when RR is selected. Handle empty workload gracefully with clear help instead of crashing. Define and test realistic numeric bounds for browser responsiveness, without changing the integer semantics in the assignment.

## Data structures and pure simulation API

Prefer typed dataclasses / type hints. Example concepts (adapt as needed):

- `ProcessSpec(pid: str, arrival: int, burst: int, input_index: int)`
- `ExecutionSegment(pid: str | None, start: int, end: int, slice_index: int | None = None)` where `None` denotes IDLE.
- `ProcessMetrics(pid, arrival, burst, first_start, completion, turnaround, waiting, response)`
- `SimulationResult(algorithm, quantum, segments, per_process_metrics, averages, optional_decision_trace)`

Keep scheduling logic pure, deterministic, and entirely separate from Streamlit widgets. Provide a single `simulate(processes, algorithm, quantum=None)` entry point, plus clear individual scheduling functions. Do not mutate caller-provided process specs. Use explicit selection/queue logic that is easy to trace in a classroom demonstration.

Compute metrics precisely:

- `turnaround = completion - arrival`
- `waiting = turnaround - burst`
- `response = first_start - arrival`
- `average_* = sum(process_metric) / number_of_processes`

Report exact integer per-process metrics and appropriately formatted averages (e.g. two decimals), without rounding internally. Include each process's ID, arrival, burst, first start, completion, turnaround, waiting, and response.

## Required professor workloads

Input order is the table row order.

**Workload A:**

| ID | Arrival | Burst |
|---|---:|---:|
| P1 | 0 | 8 |
| P2 | 1 | 4 |
| P3 | 2 | 2 |
| P4 | 4 | 1 |

**Workload B:**

| ID | Arrival | Burst |
|---|---:|---:|
| P1 | 2 | 3 |
| P2 | 2 | 1 |
| P3 | 8 | 2 |
| P4 | 9 | 1 |

Implement **Load Workload A** and **Load Workload B** (and, ideally, additional test workload presets). Evaluate A and B with FCFS, SJF, SRTF, and RR with quantum 2. The report must contain the input table, **independently reasoned hand timeline**, complete hand metrics, simulator timeline and metrics, and a side-by-side comparison for **each of the eight** algorithm/workload combinations. If any discrepancy exists, investigate and correct it rather than hiding it. Do not calculate purported "hand answers" simply by copying simulator output.

## Extra test workloads and algorithm invariants

Create at least three deliberately designed original workloads, each with explicitly reasoned expected timeline and expected metrics:

1. **Idle time**, including arrival after time 0 and/or a later gap.
2. **Simultaneous arrivals and a tie**, verifying tie-breaking by arrival then original input index.
3. **SRTF preemption**, with a later arriving strictly shorter job, including an equal-remaining-time case where preemption must **not** occur.

Additional high-value regressions:

- RR exact-quantum-boundary arrival order.
- RR when there is only one ready job: contiguous repeated quantum slices remain separately marked.
- Multiple simultaneous arrivals; jobs finishing precisely at arrival boundaries.
- SJF non-preemptive behavior even if a shorter job arrives during a burst.
- SRTF no preemption on equal remaining time.
- Original input ordering when arrivals and bursts tie.
- Both initial and mid-schedule idle time.
- Invalid input cases.

Automate verification of the properties explicitly required by the assignment:

- Total execution time per process equals its CPU burst exactly.
- No process executes before arrival.
- Segments do not overlap on the single CPU; time accounting is contiguous, covering idle correctly.
- Waiting and response are nonnegative.
- CPU is never idle while any eligible process is ready.

Prefer an independent reference/oracle for at least the essential hand-verified tests. Beware of self-confirming tests that merely compare the scheduler with itself. Use `pytest`. Report actual commands and pass/fail results.

## Streamlit website requirements and UX

Provide a clean, readable, responsive single-page website suitable for teaching. Suggested layout:

- Header: "CPU Scheduling Simulator"; short explanation of scheduling assumptions.
- Editable process table (`st.data_editor` or equivalent) supporting add/edit/remove and persistent row order, with columns `Process ID`, `Arrival Time`, `CPU Burst`.
- Buttons to load Workload A/B and reset; optionally examples for edge cases.
- Algorithm selector with a plain-English explanation of selected policy.
- Quantum integer control prominently shown/required for RR only.
- **Run Simulation** button and clear validation status.
- Interactive color-coded Plotly Gantt timeline, legend, boundaries with precise integer timestamps, and explicit grey `IDLE` segments. For RR distinguish back-to-back slices of the same process using visible separator lines/segment borders and labeled start/end times.
- Metrics table (all eight required columns) and three average metric cards.
- Optionally a scheduling decision trace/event log and comparisons across algorithms to help with the oral demo; these should not obstruct required functionality.
- Expose where useful the exact process execution order and boundaries in a textual, accessible format independent of the chart.

Keep user input state stable across Streamlit reruns. Changing a process, quantum, or algorithm must not produce stale cached results; clearly distinguish displayed results from current unsimulated edits. Make all input errors understandable without a Python traceback. Do not require login, database, external API keys, or paid hosting. Never display a student number or other private information.

## Analysis questions: answer all in PDF

1. For Workload A, identify the minimum **average waiting time** algorithm and minimum **average response time** algorithm; explain why using actual decisions/results.
2. Compare RR outcomes for quantum **1, 2, and 4** (prefer Workload A, explicitly state workload), with numerical metrics and reason why smaller quantum does not uniformly improve metrics.
3. Conditions when SJF and SRTF yield identical schedules; provide a concrete example and explanation.
4. Why real operating systems must estimate upcoming CPU bursts while this educational simulator knows exact burst lengths.
5. Starvation possibility with sustained arrivals of short jobs in SJF/SRTF, contrasted with these finite workloads.
6. Describe **one real implementation mistake** actually encountered during development, the failing test that exposed it, and the correction. If none occurs, do not invent a personal debugging anecdote: deliberately introduce and test a controlled bug in a scratch copy or explain a documented reproducible failure discovered by regression, then accurately describe what was done.

Include an explicit statement that this simulator models scheduling **policies** and does **not** reproduce the actual Ubuntu scheduler.

## Academic report and independent hand calculations

Create a final PDF, e.g. `deliverables/CSE513_Assignment1_Report.pdf`. Prefer to keep the editable authoring source in the repository (Markdown or another practical format) and use an export process to produce PDF.

Suggested report outline:

1. Assignment heading; **the verified, clickable, public website URL must appear immediately below the heading on page 1**. If deployment is still awaiting authenticated owner action, use a clearly marked placeholder and list the exact action required; do not submit a final-looking report with a fictitious URL.
2. Objective, model assumptions, algorithm descriptions and deterministic tie rules.
3. Implementation architecture and concise flow overview.
4. All eight worked examples: workload input; **manual timeline and step-by-step decisions**; manually calculated first start/completion/turnaround/waiting/response per process and all three averages; simulator results; discrepancy comparison and resolution.
5. Three student-designed test cases: purpose, expected outputs, actual results, and invariant checks.
6. Six analysis question answers with specific supporting calculations.
7. Validation/test strategy, exact test commands/results, any limitations.
8. AI assistance statement: tools used, purposes, how generated code/explanations were verified, and one suggestion genuinely corrected or rejected when applicable.
9. Local running/deployment instructions or links as appropriate.

"By hand" means **independently derived**, not necessarily handwritten. Provide the full calculation trail in typeset form. Include screenshots only as complementary proof, never in place of hand computation. If the professor separately requires literal handwriting, that requirement needs manual confirmation; the supplied assignment does not expressly mandate handwritten pages.

## Deployment — required real public website

Deployment target: **Streamlit Community Cloud** (free tier is acceptable). Follow current official instructions at:

- https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy
- https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies
- https://docs.streamlit.io/deploy/streamlit-community-cloud/share-your-app

Deployable repository conventions:

- Top-level `app.py` (main Streamlit entry point).
- Top-level `requirements.txt` with the full set of runtime dependencies (pin compatible major/minor versions or tested versions; include Streamlit and Plotly).
- Python modules/packages committed and importable on Linux, with no Windows-specific paths or assumptions.
- `README.md` describing Python version and commands to set up a virtual environment, install dependencies, run locally with `streamlit run app.py`, and run `pytest`.
- Optional `.streamlit/config.toml` for UI/theme configuration, but **do not** include credentials.
- `.gitignore` for virtualenv, caches, local secrets, and generated ephemeral artifacts. Source and reproducible deliverables must remain available.
- No paid services, database, environment secrets, or runtime local files assumed to persist across sessions.

### Deployment execution mandate

1. Build and test locally first (including Streamlit import/startup smoke check).
2. Commit the production-ready repo and push to GitHub **if authenticated tools/permissions are genuinely available**. If the GitHub destination is ambiguous or authentication/authorization blocks publishing, request only the missing owner action rather than inventing a completed push.
3. Create/deploy the app at `https://share.streamlit.io/` using the GitHub repository, branch, and entry point `app.py` **if authenticated browser/app capabilities allow it**. Otherwise provide an exact, short owner-facing click path.
4. Ensure the deployed app is public; public repository alone is not proof of website availability.
5. Visit the actual deployed `https://<assigned-name>.streamlit.app/` from a non-authenticated/private session if possible, verify it loads, and run at least Workload A / FCFS and Workload B / RR on the public site. Capture the actual working URL, deployment state, and any limitations in `DEPLOYMENT.md` and the final PDF report.
6. If full external deployment cannot be performed because of missing account access, **do not claim it is hosted**. Deliver a ready-to-deploy app and concise remaining steps; leave the real URL blank/pending until verified.
7. Streamlit Community Cloud can sleep when idle; account for warm-up and verify link accessibility before final academic submission.

## Recommended repository layout

```text
cpu-scheduling-simulator/
├── AGENTS.md
├── CSE513-Assignment-1.pdf          # If licensed/appropriate to include locally
├── app.py
├── requirements.txt
├── README.md
├── DEPLOYMENT.md
├── .gitignore
├── scheduler/
│   ├── __init__.py
│   ├── models.py
│   ├── validation.py
│   ├── fcfs.py
│   ├── sjf.py
│   ├── srtf.py
│   ├── round_robin.py
│   ├── simulate.py
│   ├── metrics.py
│   └── verification.py
├── visualization/
│   ├── __init__.py
│   └── gantt.py
├── workloads/
│   ├── __init__.py
│   └── examples.py
├── tests/
│   ├── test_fcfs.py
│   ├── test_sjf.py
│   ├── test_srtf.py
│   ├── test_round_robin.py
│   ├── test_metrics.py
│   ├── test_validation.py
│   └── test_invariants.py
├── report/
│   └── report_source.md
└── deliverables/
    ├── CSE513_Assignment1_Report.pdf
    └── cpu-scheduling-simulator-source.zip
```

The exact layout can change if a simpler layout is technically cleaner; the responsibilities and deliverables must not be omitted. Exclude the generated ZIP from itself, virtual environments, secrets, and unnecessary caches.

## Implementation approach

Work autonomously and iteratively without requiring approval at every phase:

1. Read the supplied PDF and extract a requirement checklist.
2. Write independent expected timelines/metrics on paper-like notes or typeset derivations **before consulting the implementation's output**; maintain a traceable source for those expected values.
3. Design pure models, deterministic algorithms and independent invariant checks.
4. Implement each algorithm and regression tests; run and correct failures.
5. Implement Streamlit UI and Plotly chart; explicitly inspect RR slice boundaries, idle intervals and tied arrivals.
6. Build all eight workload calculations and the three targeted tests. Cross-check results.
7. Write accurate six-question analysis and AI-use disclosure.
8. Generate/report PDF; verify PDF text, pagination, completeness and first-page link placement.
9. Test local run, verify packaging and all commands; deploy to the public web if access allows.
10. Give a concise final completion summary: features, exact test counts/commands/results, actual verified public URL or explicit hosting blocker, repo URL if created, artifacts, and any limitations.

Use straightforward, explainable algorithms instead of unnecessary abstractions. Add a decision trace that can explain an unfamiliar workload at the process-selection level. Avoid output-only stubs, placeholder metrics, mocked deployment success, or hard-coded answers for required workloads.

## Final checklist (do not declare success until checked)

- [ ] All four algorithms satisfy the exact tie/arrival/preemption rules.
- [ ] Validation rejects bad inputs cleanly.
- [ ] Workloads A and B run under all four algorithms.
- [ ] Gantt includes IDLE and visible RR boundaries.
- [ ] Eight required metric columns and three averages are correct.
- [ ] Three original edge-case workloads have expected/actual results.
- [ ] All five invariants are verified automatically.
- [ ] RR quantum 1, 2, 4 analysis and other five questions are answered.
- [ ] Eight independently hand-worked examples and comparisons appear in PDF.
- [ ] AI disclosure is honest and specific.
- [ ] Local setup, tests, Streamlit startup, and source ZIP work.
- [ ] Public deployment is verified, **or** uncompleted authorization-dependent steps are disclosed without claiming success.
- [ ] First-page public URL is clickable **once actually confirmed**.
