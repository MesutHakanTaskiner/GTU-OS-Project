# Hand Calculation Guide

Use this guide if the instructor asks to see calculations written by hand. Do not submit it without understanding the steps. Draw each Gantt chart with time marks, then write the metric formulas below it.

## Notation

- `A`: arrival time
- `B`: CPU burst
- `FS`: first start time
- `C`: completion time
- `T = C - A`: turnaround time
- `W = T - B`: waiting time
- `R = FS - A`: response time

All execution intervals are half-open: `[start, end)`.

## Workload A

Input: P1=(A0,B8), P2=(A1,B4), P3=(A2,B2), P4=(A4,B1).

### A1. FCFS

Decision notes:

1. At t=0 only P1 is ready, so P1 runs to completion.
2. P2, P3, and P4 wait in arrival order.

Gantt chart:

`0 | P1 | 8 | P2 | 12 | P3 | 14 | P4 | 15`

Calculations:

- P1: FS=0, C=8, T=8-0=8, W=8-8=0, R=0-0=0.
- P2: FS=8, C=12, T=12-1=11, W=11-4=7, R=8-1=7.
- P3: FS=12, C=14, T=14-2=12, W=12-2=10, R=12-2=10.
- P4: FS=14, C=15, T=15-4=11, W=11-1=10, R=14-4=10.

Averages:

- Average T = (8+11+12+11)/4 = 42/4 = 10.50.
- Average W = (0+7+10+10)/4 = 27/4 = 6.75.
- Average R = (0+7+10+10)/4 = 27/4 = 6.75.

### A2. Non-preemptive SJF

Decision notes:

1. At t=0 only P1 is ready, so it cannot be replaced by a future short process.
2. At t=8, choose the ready jobs by burst: P4(1), P3(2), P2(4).

Gantt chart:

`0 | P1 | 8 | P4 | 9 | P3 | 11 | P2 | 15`

Calculations:

- P1: FS=0, C=8, T=8-0=8, W=8-8=0, R=0-0=0.
- P2: FS=11, C=15, T=15-1=14, W=14-4=10, R=11-1=10.
- P3: FS=9, C=11, T=11-2=9, W=9-2=7, R=9-2=7.
- P4: FS=8, C=9, T=9-4=5, W=5-1=4, R=8-4=4.

Averages:

- Average T = (8+14+9+5)/4 = 36/4 = 9.00.
- Average W = (0+10+7+4)/4 = 21/4 = 5.25.
- Average R = (0+10+7+4)/4 = 21/4 = 5.25.

### A3. SRTF

Decision notes:

1. P1 starts at t=0.
2. At t=1, P2 burst 4 is shorter than P1 remaining 7, so P2 preempts.
3. At t=2, P3 burst 2 is shorter than P2 remaining 3, so P3 preempts.
4. P3 completes at t=4. P4(1) is then shortest.
5. After P4, run P2 remaining 3, then P1 remaining 7.

Gantt chart:

`0 | P1 | 1 | P2 | 2 | P3 | 4 | P4 | 5 | P2 | 8 | P1 | 15`

Calculations:

- P1: FS=0, C=15, T=15-0=15, W=15-8=7, R=0-0=0.
- P2: FS=1, C=8, T=8-1=7, W=7-4=3, R=1-1=0.
- P3: FS=2, C=4, T=4-2=2, W=2-2=0, R=2-2=0.
- P4: FS=4, C=5, T=5-4=1, W=1-1=0, R=4-4=0.

Averages:

- Average T = (15+7+2+1)/4 = 25/4 = 6.25.
- Average W = (7+3+0+0)/4 = 10/4 = 2.50.
- Average R = (0+0+0+0)/4 = 0.00.

### A4. Round Robin, q=2

Queue notes:

1. P1 runs 0-2. At t=2, P3 arrives before P1 is re-enqueued. Queue: P2, P3, P1.
2. P2 runs 2-4. At t=4, P4 arrives before P2 is re-enqueued. Queue: P3, P1, P4, P2.
3. Continue FIFO. Keep the last two P1 slices separate even though they are adjacent.

Gantt chart:

`0 | P1 | 2 | P2 | 4 | P3 | 6 | P1 | 8 | P4 | 9 | P2 | 11 | P1 | 13 | P1 | 15`

Calculations:

- P1: FS=0, C=15, T=15-0=15, W=15-8=7, R=0-0=0.
- P2: FS=2, C=11, T=11-1=10, W=10-4=6, R=2-1=1.
- P3: FS=4, C=6, T=6-2=4, W=4-2=2, R=4-2=2.
- P4: FS=8, C=9, T=9-4=5, W=5-1=4, R=8-4=4.

Averages:

- Average T = (15+10+4+5)/4 = 34/4 = 8.50.
- Average W = (7+6+2+4)/4 = 19/4 = 4.75.
- Average R = (0+1+2+4)/4 = 7/4 = 1.75.

## Workload B

Input: P1=(A2,B3), P2=(A2,B1), P3=(A8,B2), P4=(A9,B1).

### B1. FCFS

Decision notes:

1. The CPU is idle from 0 to 2.
2. P1 and P2 arrive together. Input order selects P1 first.
3. The CPU is idle again from 6 to 8.

Gantt chart:

`0 | IDLE | 2 | P1 | 5 | P2 | 6 | IDLE | 8 | P3 | 10 | P4 | 11`

Calculations:

- P1: FS=2, C=5, T=5-2=3, W=3-3=0, R=2-2=0.
- P2: FS=5, C=6, T=6-2=4, W=4-1=3, R=5-2=3.
- P3: FS=8, C=10, T=10-8=2, W=2-2=0, R=8-8=0.
- P4: FS=10, C=11, T=11-9=2, W=2-1=1, R=10-9=1.

Averages:

- Average T = (3+4+2+2)/4 = 11/4 = 2.75.
- Average W = (0+3+0+1)/4 = 4/4 = 1.00.
- Average R = (0+3+0+1)/4 = 4/4 = 1.00.

### B2. Non-preemptive SJF

Decision notes:

1. At t=2, P2 burst 1 is shorter than P1 burst 3, so P2 runs first.
2. P1 then runs 3-6. The CPU is idle 6-8.
3. P3 starts at 8. P4 arrives at 9, but SJF is non-preemptive, so P3 finishes first.

Gantt chart:

`0 | IDLE | 2 | P2 | 3 | P1 | 6 | IDLE | 8 | P3 | 10 | P4 | 11`

Calculations:

- P1: FS=3, C=6, T=6-2=4, W=4-3=1, R=3-2=1.
- P2: FS=2, C=3, T=3-2=1, W=1-1=0, R=2-2=0.
- P3: FS=8, C=10, T=10-8=2, W=2-2=0, R=8-8=0.
- P4: FS=10, C=11, T=11-9=2, W=2-1=1, R=10-9=1.

Averages:

- Average T = (4+1+2+2)/4 = 9/4 = 2.25.
- Average W = (1+0+0+1)/4 = 2/4 = 0.50.
- Average R = (1+0+0+1)/4 = 2/4 = 0.50.

### B3. SRTF

Decision notes:

1. The first part is the same as SJF: P2 then P1, followed by idle time.
2. P3 runs from 8. At t=9, P3 remaining=1 and P4 burst=1.
3. Equal remaining time does not preempt, so P3 continues to t=10.

Gantt chart:

`0 | IDLE | 2 | P2 | 3 | P1 | 6 | IDLE | 8 | P3 | 10 | P4 | 11`

Calculations:

- P1: FS=3, C=6, T=6-2=4, W=4-3=1, R=3-2=1.
- P2: FS=2, C=3, T=3-2=1, W=1-1=0, R=2-2=0.
- P3: FS=8, C=10, T=10-8=2, W=2-2=0, R=8-8=0.
- P4: FS=10, C=11, T=11-9=2, W=2-1=1, R=10-9=1.

Averages:

- Average T = 9/4 = 2.25.
- Average W = 2/4 = 0.50.
- Average R = 2/4 = 0.50.

### B4. Round Robin, q=2

Queue notes:

1. At t=2, P1 and P2 arrive together. Input order places P1 first.
2. P1 runs for two units, P2 completes, then P1 completes its final unit.
3. After idle 6-8, P3 finishes in one slice and P4 follows.

Gantt chart:

`0 | IDLE | 2 | P1 | 4 | P2 | 5 | P1 | 6 | IDLE | 8 | P3 | 10 | P4 | 11`

Calculations:

- P1: FS=2, C=6, T=6-2=4, W=4-3=1, R=2-2=0.
- P2: FS=4, C=5, T=5-2=3, W=3-1=2, R=4-2=2.
- P3: FS=8, C=10, T=10-8=2, W=2-2=0, R=8-8=0.
- P4: FS=10, C=11, T=11-9=2, W=2-1=1, R=10-9=1.

Averages:

- Average T = (4+3+2+2)/4 = 11/4 = 2.75.
- Average W = (1+2+0+1)/4 = 4/4 = 1.00.
- Average R = (0+2+0+1)/4 = 3/4 = 0.75.

## RR Quantum Comparison to Write

Use Workload A and include this small table:

| Quantum | Average turnaround | Average waiting | Average response |
|---:|---:|---:|---:|
| 1 | 8.50 | 4.75 | 0.75 |
| 2 | 8.50 | 4.75 | 1.75 |
| 4 | 9.25 | 5.50 | 3.75 |

Short explanation: q=1 gives earlier first service to the short jobs, so response improves. However, completion order and repeated rotations mean that turnaround and waiting do not automatically improve. In Workload A, q=1 and q=2 have the same average turnaround and waiting values.

## Suggested Handwritten Page Order

1. Write the metric formulas and interval convention.
2. Copy the Workload A input table.
3. Draw four Workload A Gantt charts and write the four metric calculations under each.
4. Copy the Workload B input table.
5. Draw four Workload B Gantt charts and write the four metric calculations under each.
6. Add the RR q=1,2,4 comparison table.
7. Finish with: `All hand-calculated results matched the simulator output.`

